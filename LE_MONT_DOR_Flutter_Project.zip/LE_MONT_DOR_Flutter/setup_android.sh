#!/usr/bin/env bash
set -e
flutter create . --platforms=android
flutter pub get
echo "تم إعداد المشروع. شغّله بالأمر: flutter run"
