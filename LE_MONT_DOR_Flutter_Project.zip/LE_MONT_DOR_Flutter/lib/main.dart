import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const MontDorApp());

const navy = Color(0xFF073B82);
const blue = Color(0xFF1768D2);
const pale = Color(0xFFF4F7FF);
const gold = Color(0xFFFFC928);

class Product {
  final String name, subtitle, image;
  final int price;
  const Product(this.name, this.subtitle, this.image, this.price);
}

const products = <Product>[
  Product('Junior Fromage Fondu', 'جبن ذائب للأطفال – 420غ', 'assets/images/mont_dor_junior.jpg', 120),
  Product('Cuisine & Sandwich', 'تحضيرة غذائية', 'assets/images/mont_dor_cuisine.jpg', 180),
];

class MontDorApp extends StatelessWidget {
  const MontDorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "LE MONT D'OR",
    theme: ThemeData(
      useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: navy),
      scaffoldBackgroundColor: pale, fontFamily: 'Roboto',
    ),
    home: const StorePage(),
  );
}

class StorePage extends StatefulWidget {
  const StorePage({super.key});
  @override State<StorePage> createState() => _StorePageState();
}

class _StorePageState extends State<StorePage> {
  final Map<int,int> cart = {};
  final search = TextEditingController();
  int tab = 0;
  String query = '';
  int get count => cart.values.fold(0, (a,b)=>a+b);
  int get total => cart.entries.fold(0, (a,e)=>a+products[e.key].price*e.value);

  void add(int i) => setState(()=>cart[i]=(cart[i]??0)+1);
  void change(int i, int d) => setState(() {
    final n=(cart[i]??0)+d;
    if(n<=0) { cart.remove(i); } else { cart[i]=n; }
  });

  Future<void> checkout() async {
    if(cart.isEmpty) return;
    final lines = cart.entries.map((e)=>'${products[e.key].name} × ${e.value} = ${products[e.key].price*e.value} دج').join('\n');
    const phone = ''; // ضع رقم واتساب المتجر بصيغة دولية دون +، مثال: 213XXXXXXXXX
    final message = 'طلب جديد من متجر LE MONT D’OR\n$lines\nالمجموع: $total دج\n\nالاسم والعنوان:';
    if(phone.isEmpty) {
      await showDialog<void>(context: context, builder: (c)=>AlertDialog(
        title: const Text('إعداد واتساب المتجر', textDirection: TextDirection.rtl),
        content: const Text('أضف رقم واتساب المتجر في المتغير phone داخل lib/main.dart لتفعيل إرسال الطلبات.', textDirection: TextDirection.rtl),
        actions: [TextButton(onPressed: ()=>Navigator.pop(c), child: const Text('حسنًا'))],
      ));
      return;
    }
    final uri=Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(message)}');
    if(await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override Widget build(BuildContext context) {
    final shown=products.asMap().entries.where((e)=>('${e.value.name} ${e.value.subtitle}').toLowerCase().contains(query.toLowerCase())).toList();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white, surfaceTintColor: Colors.white, centerTitle: true,
        leading: IconButton(onPressed: ()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('متجر LE MONT D’OR'))), icon: const Icon(Icons.menu, color: navy)),
        title: Column(children: const [Text("LE MONT D’OR", style: TextStyle(color: navy,fontWeight: FontWeight.w900,letterSpacing: 1.2)),Text('مونت دور',style: TextStyle(color: navy,fontWeight: FontWeight.bold,fontSize: 14))]),
        actions: [Padding(padding: const EdgeInsetsDirectional.only(end: 12), child: Stack(clipBehavior: Clip.none, children:[
          IconButton(onPressed: ()=>setState(()=>tab=2), icon: const Icon(Icons.shopping_cart_outlined,color: navy,size:29)),
          if(count>0) Positioned(right:0,top:0,child: CircleAvatar(radius:9,backgroundColor: Colors.red,child: Text('$count',style: const TextStyle(color:Colors.white,fontSize:10))))
        ]))],
      ),
      body: tab==2 ? cartPage() : tab==3 ? ordersPage() : tab==4 ? aboutPage() : home(shown),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, backgroundColor: Colors.white, indicatorColor: const Color(0xFFE5EEFF),
        onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),
          NavigationDestination(icon:Icon(Icons.grid_view),label:'المنتجات'),
          NavigationDestination(icon:Icon(Icons.shopping_bag_outlined),label:'سلتي'),
          NavigationDestination(icon:Icon(Icons.receipt_long),label:'طلباتي'),
          NavigationDestination(icon:Icon(Icons.support_agent),label:'الدعم'),
        ],
      ),
    ));
  }

  Widget home(List<MapEntry<int,Product>> shown) => ListView(padding: const EdgeInsets.all(16), children:[
    Container(height:190, decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[navy,blue]),), child:Stack(children:[
      const Positioned(right:18,top:20,child:Text('LE MONT D’OR',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:22))),
      const Positioned(right:18,top:57,child:Text('جودة عالية ومذاق لا يُقاوم',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:19))),
      Positioned(left:8,bottom:0,child:Image.asset('assets/images/mont_dor_junior.jpg',width:155,height:120,fit:BoxFit.contain)),
      const Positioned(right:18,bottom:16,child:Text('اكتشفوا منتجاتنا',style:TextStyle(color:gold,fontWeight:FontWeight.bold))),
    ])),
    const SizedBox(height:16),
    TextField(controller:search,onChanged:(v)=>setState(()=>query=v),decoration:InputDecoration(hintText:'ابحث عن منتج...',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(30),borderSide:BorderSide.none))),
    const SizedBox(height:22),
    const Text('منتجاتنا المميزة',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900,color:navy)),
    const SizedBox(height:12),
    ...shown.map((e)=>productCard(e.key,e.value)),
    if(shown.isEmpty) const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('لا توجد منتجات مطابقة'))),
    const SizedBox(height:12),
    const Text('ملاحظة: الأسعار المعروضة تجريبية ويمكن تعديلها في قائمة products داخل lib/main.dart.',style:TextStyle(color:Colors.black54,fontSize:12)),
  ]);

  Widget productCard(int i, Product p)=>Card(color:Colors.white,elevation:1,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20)),clipBehavior:Clip.antiAlias,margin:const EdgeInsets.only(bottom:14),child:Column(children:[
    SizedBox(height:175,width:double.infinity,child:Image.asset(p.image,fit:BoxFit.cover)),
    Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Text(p.name,textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17)),
      Text(p.subtitle,textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54)),
      const SizedBox(height:6),
      Text('${p.price} دج',textAlign:TextAlign.center,style:const TextStyle(fontSize:22,color:navy,fontWeight:FontWeight.w900)),
      const SizedBox(height:8),
      FilledButton.icon(onPressed:()=>add(i),icon:const Icon(Icons.add_shopping_cart),label:const Text('أضف إلى السلة'),style:FilledButton.styleFrom(backgroundColor:navy)),
    ]))
  ]));

  Widget cartPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('سلة المشتريات',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:navy)),
    if(cart.isEmpty) const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('السلة فارغة حاليًا'))),
    ...cart.entries.map((e)=>Card(color:Colors.white,child:ListTile(title:Text(products[e.key].name),subtitle:Text('${products[e.key].price} دج × ${e.value}'),trailing:Wrap(mainAxisSize:MainAxisSize.min,children:[
      IconButton(onPressed:()=>change(e.key,-1),icon:const Icon(Icons.remove_circle_outline)),
      IconButton(onPressed:()=>change(e.key,1),icon:const Icon(Icons.add_circle_outline)),
    ])))),
    const SizedBox(height:12),
    Text('المجموع: $total دج',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:20,color:navy)),
    const SizedBox(height:12),
    FilledButton.icon(onPressed:cart.isEmpty?null:checkout,icon:const Icon(Icons.send),label:const Text('تأكيد الطلب عبر واتساب')),
  ]);

  Widget ordersPage()=>const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('ستظهر طلباتك هنا بعد ربط المتجر بنظام استقبال الطلبات.',textAlign:TextAlign.center)));
  Widget aboutPage()=>const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('للطلب أو الاستفسار، أضف رقم واتساب المتجر في إعدادات التطبيق.',textAlign:TextAlign.center)));
}
